//
//  DetailViewController.swift
//  Movies
//
//  Created by user201951 on 11/30/21.
//

import Foundation
import UIKit

class DetailsViewController: UIViewController {
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var imageViewPoster: UIImageView!
    @IBOutlet weak var labelReleaseDataAverage: UILabel!
    @IBOutlet weak var labelOverview: UILabel!
    
    var receivedMovieTitle: String = ""
    var receivedMoviePosterPath: String = ""
    var receivedMovieOverview: String = ""
    var receivedMovieReleaseDate: String = ""
    var receivedMovieVoteAverage: Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.title = "Movie Details"
        iniciarView()
        
    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    private func iniciarView() {
        let dateYear = receivedMovieReleaseDate.prefix(4)
        let voteAverage = String(receivedMovieVoteAverage)
        
        labelTitle.text = receivedMovieTitle
        labelReleaseDataAverage.text = "\(dateYear)  Avaliação: \(voteAverage)"
        labelOverview.text = receivedMovieOverview
        imageViewPoster.kf.setImage(with: "\(receivedMoviePosterPath )".url)
        
    }
    
}
