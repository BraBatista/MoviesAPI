//
//  ViewController.swift
//  Movies
//
//  Created by user201951 on 11/29/21.
//

import UIKit

private let identifier = "MovieCell"

class MoviesViewController: UIViewController {
    @IBOutlet private weak var collectionView : UICollectionView!
    private var movies: [Movie]?
    private var page: Int = 1
    private var totalPages: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Top Rated Movies"
        let width = (view.frame.size.width - 20) / 2
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: width, height: 290)
        
        fetch()
    }

    private func fetch(_ page: Int = 1) {
        API.fetchTopRatedMovies(page) { data in
            self.totalPages = data.totalPages
            self.movies = data.results
            self.collectionView.reloadData()
        }
    }
    
    private func loadMoreData() {
        if page < totalPages {
            page += 1
            OperationQueue.main.addOperation {
                API.fetchTopRatedMovies(self.page) { data in
                    self.movies? += data.results
                    self.collectionView.reloadData()
                }
            }
        }
    }
}

extension MoviesViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! MovieCollectionViewCell
        cell.movie = movies?[indexPath.item]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        guard let count = movies?.count else { fatalError() }
        if indexPath.item == count-1 {
            self.loadMoreData()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as? DetailsViewController
        vc?.receivedMovieTitle = movies?[indexPath.row].title ?? ""
        vc?.receivedMoviePosterPath = movies?[indexPath.row].posterPath ?? ""
        vc?.receivedMovieReleaseDate = movies?[indexPath.row].releaseDate ?? ""
        vc?.receivedMovieVoteAverage = movies?[indexPath.row].voteAverage ?? 0.0
        vc?.receivedMovieOverview = movies?[indexPath.row].overview ?? ""
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    		
}
