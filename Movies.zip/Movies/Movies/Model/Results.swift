//
//  Results.swift
//  Movies
//
//  Created by user201951 on 11/29/21.
//

import Foundation

struct Results: Codable {
    let results: [Movie]
    let page: Int
    let totalPages: Int
    let totalResults: Int
}
